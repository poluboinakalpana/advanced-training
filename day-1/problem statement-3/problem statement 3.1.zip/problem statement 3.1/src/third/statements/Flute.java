package third.statements;

import javax.sound.midi.Instrument;

public class Flute extends Instrument {

	@Override
	public Object getData() {
		// TODO Auto-generated method stub
		return null;
	}

}
