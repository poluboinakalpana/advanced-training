package third.statements;

public class Syrup extends medicine {

}
