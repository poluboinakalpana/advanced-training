package third.statements;

public class Ointment extends medicine {

}
