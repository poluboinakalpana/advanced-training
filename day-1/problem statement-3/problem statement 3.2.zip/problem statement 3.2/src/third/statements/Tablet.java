package third.statements;

public class Tablet extends medicine {

}
