package third.statements;

public class medicine {

	public void displayLabel() {
		// TODO Auto-generated method stub
		
	}

}
